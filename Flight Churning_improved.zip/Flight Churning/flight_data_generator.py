import pandas as pd
import random
from datetime import datetime, timedelta
from faker import Faker

fake = Faker()

# Settings
num_passengers = 100
routes = [("Port Harcourt", "Abuja"), ("Abuja", "Port Harcourt"), ("Abuja", "Owerri"), ("Owerri", "Abuja"),
          ("Lagos", "Uyo"), ("Uyo", "Lagos"), ("Lagos", "Enugu"), ("Enugu", "Lagos")]
classes = ["Economy", "Business","First Class"]

data = []
for i in range(num_passengers):
    name = fake.name()
    ticket_number = f"T{1000 + i}"
    flight_count = random.choice([1, 2, 3])  # max 3 flights
    base_route = random.choice(routes)
    # base_date = fake.date_between(start_date="-5y", end_date="today")
    # base_date = fake.date_between(start_date="-5y", end_date="2024-03-31")
    end_date = datetime.strptime("2024-03-31", "%Y-%m-%d").date()
    base_date = fake.date_between(start_date="-5y", end_date=end_date)
    passenger_id = f"P{str(1000 + i).zfill(4)}"

    for j in range(flight_count):
        if j == 0:
            from_loc, to_loc = base_route
        elif j == 1:
            to_loc, from_loc = base_route  # reverse
        else:
            from_loc, to_loc = random.choice(routes)  # totally new

        flight_date = base_date + timedelta(days=random.randint(5, 90) * j)
        support_calls = random.randint(0, 3)
        delay = random.randint(0, 120)
        travel_class = random.choice(classes)

        data.append({
            "PNR": passenger_id,
            "name": name,
            "ticket_number": ticket_number,
            "from": from_loc,
            "to": to_loc,
            "route": f"{from_loc} → {to_loc}",
            "flight_date": flight_date.strftime("%Y-%m-%d"),
            "support_calls": support_calls,
            "delay_minutes": delay,
            "class": travel_class
        })

# Save to CSV
df = pd.DataFrame(data)
df.to_csv("flight_churn_with_ids.csv", index=False)





